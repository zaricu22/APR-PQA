import os
import shutil

# Specify folder with analyzed duplciates
work_folder = os.path.join('..','extracted - 80AllDup')
# Specify origin folder with all separated versions of projects
input_folder = os.path.join('..','separated')

for auto_folder in os.listdir(work_folder):
    buggy_folder = os.path.basename(auto_folder).replace('auto', 'buggy')
    buggy_folder_path = os.path.join(input_folder, buggy_folder)
    out_buggy_path = os.path.join(work_folder, buggy_folder)
    
    manual_folder = os.path.basename(auto_folder).replace('auto', 'manual')
    manual_folder_path = os.path.join(input_folder, manual_folder)
    out_manual_path = os.path.join(work_folder, manual_folder)
    if not os.path.exists(out_buggy_path) and os.path.exists(buggy_folder_path):
        print(buggy_folder_path)
        shutil.copytree(buggy_folder_path, out_buggy_path)
    if not os.path.exists(out_manual_path) and os.path.exists(manual_folder_path):
        print(manual_folder_path)
        shutil.copytree(manual_folder_path, out_manual_path)
