import os
import shutil

# Specify folder with 'patched_buggy_files'
work_folder = os.path.join('..', 'patches')
# Specify full path to output folder
out_folder = os.path.join(os.getcwd(), '..', 'separated')

# Separate project versions
# NOTE: After this process you can manually move 'auto' version to separate folder
# and use external software or scripts to delete duplciates.
# Use delete-empties.py to delete empty 'auto' version folders
# Use move-missing-versions.py to fetch missing versons which corresponde to remaining 'auto' folders
extract_folder = os.path.join(os.path.dirname(work_folder), out_folder)
if not os.path.exists(extract_folder):
    os.mkdir(extract_folder)
for root, dirs, files in os.walk(work_folder):
    for d in dirs:
        if 'buggy' in d or 'manual' in d or 'auto' in d:
            version_folder = os.path.join(root, d)
            patch = os.listdir(version_folder)
            if patch:
                patch = patch[0]
            splited_name = str(root).split('-')
            extract_name = splited_name[2]+'-'+splited_name[3]+'-'+splited_name[4][0:5]+'-'+d
            out_dir = os.path.join(out_folder, extract_name)
            print(out_dir)
            if os.path.exists(out_dir):
                for i in range(1,20):
                    new_extract_name = extract_name+'-'+str(i)
                    out_dir = os.path.join(extract_folder, new_extract_name)
                    if not os.path.exists(out_dir):
                        break
            if not os.path.exists(out_dir):
                os.mkdir(out_dir)
            shutil.copyfile(os.path.join(version_folder, patch), os.path.join(out_dir, patch))


# Rename C files with version extension
for root, dirs, files in os.walk(out_folder):
    for f in files:
        if '.c-' in f:
            file_path = os.path.join(root, f)
            new_filename_path = os.path.join(root, f.split('-')[0])
            print(file_path)
            print(new_filename_path)
            os.rename(file_path, new_filename_path)
