import os
import shutil
import subprocess

# Specify full path to folder with separated_developer_patches
work_folder = os.path.join(os.getcwd(), '..', 'patches')

# Patch buggy files
for d in os.listdir(work_folder):
    dir_path = os.path.join(work_folder, d)
    if 'buggy' not in os.listdir(dir_path):
        shutil.rmtree(dir_path)
        print('deleted: '+dir_path)

# Patch buggy files
for root, dirs, files in os.walk(work_folder):
    for f in files:
        if '.c' not in f and '.rej' not in f:
            repair_folder = root
            buggy_folder = root.replace('auto', 'buggy')
            if os.path.exists(repair_folder) and os.path.exists(buggy_folder):
                for f in os.listdir(repair_folder):
                    patch_file = os.path.join(repair_folder, f)
                    buggy_filename = os.listdir(buggy_folder)[0]
                    buggy_file = os.path.join(buggy_folder, buggy_filename)
                    output_file_path = os.path.join(repair_folder, buggy_filename+'-'+f.replace('.patch',''))
                    patch_command = ['patch', "\""+buggy_file+"\"", '-i', "\""+patch_file+"\"", '-o', "\""+output_file_path+"\""]
                    if os.name == 'posix':
                        dos2unix_proc = subprocess.run('dos2unix ' + "\""+buggy_file+"\"", shell=True)
                    # print(patch_command)
                    patch_proc = subprocess.run(patch_command)
                    # Delete rejected patches
                    if os.path.exists(output_file_path+".rej"):
                        print('bad patch: '+patch_file)
                        os.remove(output_file_path)
                        os.remove(output_file_path+".rej")
                    # Delete empty patched files
                    if os.path.exists(output_file_path) and os.path.getsize(output_file_path) == 0:
                        print('empty patch: '+patch_file)
                        os.remove(output_file_path)

# Delete 'patch_files'
for root, dirs, files in os.walk(work_folder):
    for d in dirs:
        dir_path = os.path.join(root, d)
        if 'auto' in dir_path:
            dir_content = os.listdir(dir_path)
            if '.c' in str(dir_content) and '.patch' in str(dir_content):
                for f in dir_content:
                    if '.patch' in f:
                        os.remove(os.path.join(dir_path, f))
                    # If patched file is in some subfolder hierarchy 
##                    if '.c' in f:
##                        file_path = os.path.join(dir_path, f)
##                        auto_folder = dir_path.split('auto')[0]+os.sep+'auto'
##                        shutil.move(file_path, os.path.join(auto_folder, f))

# Delete empty folders
for root, dirs, files in os.walk(work_folder, topdown=False):
    for dir_path in dirs:
        folder_path = os.path.join(root, dir_path)
        if not os.listdir(folder_path):  # Check if folder is empty
            os.rmdir(folder_path)                      
                        

