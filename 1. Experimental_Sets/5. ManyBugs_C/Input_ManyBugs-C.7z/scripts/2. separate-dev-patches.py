import os
import shutil

# Specify folder with 'extracted_patches'
work_folder = os.path.join('..', 'patches')


# Script divide buggy and manual program version
# in separate folders based on corresponding .diff file
# NOTE: script will print 'wrong' for files which should be manually divided

for root, dirs, files in os.walk(work_folder):
    for d in dirs:
        dir_path = os.path.join(root, d)
        dir_content = os.listdir(dir_path)
        if '-diff' in str(dir_content):
            diff_file = ''
            for c in dir_content:
                if '-diff' in c:
                    diff_file = os.path.join(dir_path, c)
            check_lines = []
            delete_diff_flag = False

            patch_content = ''
            with open(diff_file, 'r') as file:
                patch_content = file.readlines()
                for l in patch_content:
                    if l.startswith('>'):
                        check_lines.append(l.lstrip('>').strip())
                if len(check_lines) == 0:
                    for l in patch_content:
                        if l.startswith('<'):
                            check_lines.append(l.lstrip('<').strip())
                            delete_diff_flag = True
            for c in dir_content:
                if '-diff' in c:
                    dir_content.remove(c)

            file1_path = os.path.join(dir_path, dir_content[0])
            file1 = ''
            file2_path = os.path.join(dir_path, dir_content[1])
            file2 = ''
            patched_file_path = ''
            with open(file1_path, 'r') as f1:
                file1 = f1.read()
            with open(file2_path, 'r') as f2:
                file2 = f2.read()
            for cl in check_lines:
                if len(cl) > 5:
                    if not delete_diff_flag:
                        if str(patch_content).count(cl) > 1:
                            patched_file_path = 'wrong'
                            break
                        if cl in file1:
                            if patched_file_path == file2_path:
                                patched_file_path = 'wrong'
                                break
                            patched_file_path = file1_path
                        elif cl in file2:
                            if patched_file_path == file1_path:
                                patched_file_path = 'wrong'
                                break
                            patched_file_path = file2_path
                    else:
                        if cl not in file1:
                            patched_file_path = file2_path
                        elif cl not in file2:
                            patched_file_path = file1_path

            if patched_file_path == 'wrong':
                print(dir_path)
                print(patched_file_path)
            else:
                if 'diff' in dir_path:
                    project_path = dir_path.split(os.sep+'diff')[0]
                elif 'dev-fix' in dir_path:
                    project_path = dir_path.split(os.sep+'dev-fix')[0]

                manual_file_path = os.path.join(project_path, 'manual', os.path.basename(patched_file_path))
                manual_dir_path = os.path.dirname(manual_file_path)
                if not os.path.exists(manual_dir_path):
                    os.makedirs(manual_dir_path)
                else:
                    shutil.rmtree(manual_dir_path)
                    os.makedirs(manual_dir_path)
                shutil.copyfile(patched_file_path, manual_file_path)
                # print(patched_file_path)
                # print(manual_file_path)

                buggy_org_file_path = ''
                if patched_file_path == file1_path:
                    buggy_file_path = os.path.join(project_path, 'buggy', os.path.basename(file2_path))
                    buggy_org_file_path = file2_path
                else:
                    buggy_file_path = os.path.join(project_path, 'buggy', os.path.basename(file1_path))
                    buggy_org_file_path = file1_path
                buggy_dir_path = os.path.dirname(buggy_file_path)
                if not os.path.exists(buggy_dir_path):
                    os.makedirs(buggy_dir_path)
                else:
                    shutil.rmtree(buggy_dir_path)
                    os.makedirs(buggy_dir_path)
                shutil.copyfile(buggy_org_file_path, buggy_file_path)
                # print(buggy_org_file_path)
                # print(buggy_file_path)


# Delete 'dev-fix' and 'diffs' folder after separation           
for root, dirs, files in os.walk(work_folder):
    for d in dirs:
        if 'dev-fix' in d or 'diff' in d:
            if os.path.exists(os.path.join(root, 'buggy')):
                shutil.rmtree(os.path.join(root, d))

# Correct 'prophet' patch files in separate folder
prophet_patch_dirs = []
for f in os.listdir(work_folder):
    if 'prophet' in f:
        prophet_patch_dirs.append(os.path.join(work_folder, f))
for pd in prophet_patch_dirs:
    auto_folder = os.path.join(pd, 'auto')
    new_patches_dir = os.path.join(pd, 'patches')
    if not os.path.exists(new_patches_dir) and not os.path.exists(auto_folder):
        os.mkdir(new_patches_dir)
    for p in os.listdir(pd):
        if '.c' in p:
            shutil.move(os.path.join(pd, p), new_patches_dir)


# Move auto file if it is in some subfolder hierarchy
for root, dirs, files in os.walk(work_folder):
    for f in files:
        if '.c' in f and 'auto' in root:
            file_path = os.path.join(root, f)
            auto_folder = root.split('auto')[0]+'auto'
            if not root in auto_folder:
                print(file_path)
                print(auto_folder)
                shutil.move(file_path, os.path.join(auto_folder, f))
# Than delete empty folders
for root, dirs, files in os.walk(work_folder, topdown=False):
    for dir_path in dirs:
        folder_path = os.path.join(root, dir_path)
        if not os.listdir(folder_path):  # Check if folder is empty
            os.rmdir(folder_path)  


# Rename 'patches' folders to 'auto'
for root, dirs, files in os.walk(work_folder):
    for d in dirs:
        if 'patches' in d:
            os.rename(os.path.join(root, d), os.path.join(root, 'auto'))



