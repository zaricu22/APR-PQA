import os

# Specify folder with 'manually_analyzed_duplciates'
work_folder = os.path.join('..','extracted - 80AllDup')

# Delete empty folders
for root, dirs, files in os.walk(work_folder, topdown=False):
    for dir_path in dirs:
        folder_path = os.path.join(root, dir_path)
        if not os.listdir(folder_path):  # Check if folder is empty
            os.rmdir(folder_path)







