import os
import glob
import shutil

# # https://github.com/TruX-DTF/APR-Efficiency

output_folder = os.path.join(os.getcwd(), 'APREff-correct (10.1145-3377811.3380338)')
if not os.path.exists(output_folder):
    os.mkdir(output_folder)

bugPatches = glob.glob(os.path.join(os.getcwd(), 'Patches', '**', '**', '*_C*', '*.txt'))
for p in bugPatches:
    splitPath = p.split(os.sep)
    pathNodes = len(splitPath)
    aprTool = splitPath[pathNodes-3]
    patchVersion = splitPath[pathNodes-1].split('_',1)[1]
    projectVersion = splitPath[pathNodes-2].split('_',1)[0]
    filename = projectVersion+'_'+aprTool+'_'+patchVersion
    shutil.copyfile(p, os.path.join(output_folder, filename))
      
  
