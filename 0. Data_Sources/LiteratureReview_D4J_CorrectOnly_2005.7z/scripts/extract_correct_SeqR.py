import os
import glob
import shutil

# https://github.com/ASSERT-KTH/sequencer

output_folder = os.path.join(os.getcwd(), 'SeqR-correct (10.48550-arXiv.2205.01972)')
if not os.path.exists(output_folder):
    os.mkdir(output_folder)

correctPatches = glob.glob(os.path.join(os.getcwd(), 'results', 'Defects4J_patches', '*', '*_correct*'))
for p in correctPatches:
    splitedPath = p.split(os.sep)
    shutil.copytree(p, os.path.join(output_folder, splitedPath[len(splitedPath)-2], splitedPath[len(splitedPath)-1]))

    
      
  

