import os
import glob
import json
import shutil

# https://github.com/Ultimanecat/DefectRepairing

output_folder = os.path.join(os.getcwd(), 'PatchSim-correct (10.1145-3180155.3180182)')
if not os.path.exists(output_folder):
    os.mkdir(output_folder)

patches_folder = os.path.join(os.getcwd(), 'tool', 'patches')
for file in glob.glob(os.path.join(patches_folder, 'INFO', '*.json')):
    f = open(file)
    patchJson = json.loads(f.read())
    if patchJson['correctness'] == 'Correct':
        name = patchJson['project']+'-'+patchJson['bug_id']+'_'+patchJson['tool']+'_'+patchJson['ID']
        shutil.copyfile(os.path.join(patches_folder, patchJson['ID']),
                        os.path.join(output_folder, name))
