import re
import os
import requests
import time
from urllib.parse import urlparse

# REQUIREMENTS: https://github.com/program-repair/defects4j-dissection
# In-archive provided 'defects4j-patch.md'
patch_list_filename = os.path.join('apapr-patch-list.txt')

# Create the output folder if it doesn't exist
output_folder = 'APAPR-Dcorrect (10.1007-s10664-020-09920-w)'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)


def download_content(url, filename):
    response = requests.get(url)
    if response.status_code == 200:
        # By default, response.text add empty line after each line of text
        content = response.text.splitlines()

        # Remove one empty line after each non-empty line
        filtered_content = []
        for i, line in enumerate(content):
            stripped_line = line.strip()
            if stripped_line:
                filtered_content.append(stripped_line)
                if i < len(content) - 1 and not content[i+1].strip():
                    filtered_content.append('')  # Add an empty line
       
        with open(filename, 'w', encoding='utf-8') as file:
            file.write('\n'.join(content))

        print(f"Downloaded content from {url}: {filename}")
    else:
        print(f"Failed to download content from {url}")
                            

# Start the timer
start_time = time.time()

# Load template from MD file
with open(patch_list_filename, 'r') as file:
    patch_list_template = file.readlines()

tools = {'ACS','Arja','CapGen','DeepRepair','Elixir','HDRepair','Jaid','Nopol2015','SOFix','SequenceR','SimFix','SketchFix','ssFix', 'JGenProg2015'}
projects = {'Math','Lang','Closure','Mockito','Time','Chart'}
corr_overf_flag = ''
tool_flag = ''
project_flag = ''
base_url = 'https://anonymous.4open.science/api/repo/cffe573f-61ab-4d99-9e7c-dc769d657e75/file/Patches/'

i = 0
for l in patch_list_template:
    line = l.strip()
    
    if 'correct' in line:
        corr_overf_flag = 'Dcorrect'
    elif 'overfitting' in line:
        corr_overf_flag = 'Doverfitting'
    out_dir = os.path.join(output_folder, corr_overf_flag)
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    url = base_url+corr_overf_flag+'/'

    # Set-up 'tool' folder
    if line in tools:
        tool_flag = line
    # Set-up 'project' folder
    elif line in projects:
        project_flag = line  
    else:
        out_dir = os.path.join(out_dir, tool_flag, project_flag)
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        # Download only file in 'project' folder
        if line.split('/')[0] in projects and '.patch' in line:
            project_flag = line.split('/')[0]
            out_dir = os.path.join(output_folder, corr_overf_flag, tool_flag, project_flag)
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            url = url+tool_flag+'/'+line
            filename = os.path.join(output_folder, url.replace(base_url,''))
##          print(filename)
            i += 1
            print(str(i)+". "+line)
            if not os.path.exists(filename):
                download_content(url, filename)
        # Download 'project' folder with many files
        elif line.endswith('.patch'):
            url = url+tool_flag+'/'+project_flag+'/'+line
            filename = os.path.join(output_folder, url.replace(base_url,''))
##          print(filename)
            i += 1
            print(str(i)+". "+line)
            if not os.path.exists(filename):
                download_content(url, filename)
        # Set-up both 'tool' and 'project' folder
        elif line.split('/')[0] in tools and line.split('/')[1] in projects:
            tool_flag = line.split('/')[0]
            project_flag = line.split('/')[1]
            out_dir = os.path.join(output_folder, corr_overf_flag, tool_flag, project_flag)
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)


# Stop the timer
end_time = time.time()

# Calculate the execution time
execution_time = end_time - start_time
# Print the execution time
print()
print(f"Execution time: {execution_time} seconds")

