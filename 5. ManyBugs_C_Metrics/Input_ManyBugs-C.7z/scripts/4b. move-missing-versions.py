import os
import shutil

# Specify folder with analyzed duplciates
work_folder = os.path.join('..','extracted - 80AllDup')
# Specify origin folder with all separated versions of projects
input_folder = os.path.join('..','separated')

for repaired_folder in os.listdir(work_folder):
    buggy_folder = os.path.basename(repaired_folder).replace('repaired', 'buggy')
    buggy_folder_path = os.path.join(input_folder, buggy_folder)
    out_buggy_path = os.path.join(work_folder, buggy_folder)
    
    fixed_folder = os.path.basename(repaired_folder).replace('repaired', 'fixed')
    fixed_folder_path = os.path.join(input_folder, fixed_folder)
    out_fixed_path = os.path.join(work_folder, fixed_folder)
    if not os.path.exists(out_buggy_path) and os.path.exists(buggy_folder_path):
        print(buggy_folder_path)
        shutil.copytree(buggy_folder_path, out_buggy_path)
    if not os.path.exists(out_fixed_path) and os.path.exists(fixed_folder_path):
        print(fixed_folder_path)
        shutil.copytree(fixed_folder_path, out_fixed_path)
