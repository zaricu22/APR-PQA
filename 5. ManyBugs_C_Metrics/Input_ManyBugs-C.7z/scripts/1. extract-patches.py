import os
import tarfile

# Replication Package for "Trust Enhancement Issues in Program Repair"
# https://zenodo.org/record/5908381

# REQUIREMENT: Specify path to 'TEIPR_results' folder 
work_folder = os.path.join('..', 'TEIPR_results')
# Specify path to desired output_folder
output = os.path.join('..', 'patches')

for root, dirs, files in os.walk(work_folder):
    for file in files:
        tar_path = os.path.join(root, file)
        filename = file.replace('.tar.gz','')
        if 'tar.gz' in file:
            tarf = tarfile.open(tar_path, 'r:gz')
            tar_content = tarf.getnames()
            tar_patches = []
            patch_flag = False
            if 'prophet' in file:
                for mem in tar_content:
                    if 'diff' not in mem and 'dev-fix' not in mem and '.c' in mem:
                        tar_patches.append(mem)
                        patch_flag = True
                if patch_flag:
                    for mem in tar_content:
                        if filename+'/dev-fix' in mem:
                            tar_patches.append(mem)
                        elif filename+'/diff' in mem:
                            tar_patches.append(mem)
            # Exclude certain tools because of their incorrect patch formats
            elif 'cpr' not in file and 'fix2fit' not in file and 'genprog' not in file:
                for mem in tar_content:
                    if filename+'/patches' in mem:
                        tar_patches.append(mem)
                        patch_flag = True
                if patch_flag:
                    for mem in tar_content:
                        if filename+'/dev-fix' in mem:
                            tar_patches.append(mem)
                        elif filename+'/diff' in mem:
                            tar_patches.append(mem)
            for p in tar_patches:
                if not os.path.exists(os.path.join(output,p)):
                    tarf.extract(p, output)
