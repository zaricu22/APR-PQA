import os
import uuid

# Specify path to folder with separated projects by version (buggy, fixed, repaired)
work_folder = os.path.join('..','extracted - 80AllDup')

# REQUIREMENT: Use in-archive provided template.vcxproj and template.sln
vcxproj_temp_file = 'template.vcxproj'
sln_temp_file = 'template.sln'

# Predefined placeholders in above template.files
temp_sln_project = "\nProject(\"{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}\") = \"RootNamespace-Placeholder\", \"RootFolder-Placeholder\RootFile-Placeholder.vcxproj\", \"{ProjectGuid-Placeholder}\" \nEndProject"
temp_sln_section = "\n\t\t{ProjectGuid-Placeholder}.Debug|x64.ActiveCfg = Debug|x64 \n\t\t{ProjectGuid-Placeholder}.Debug|x64.Build.0 = Debug|x64 \n\t\t{ProjectGuid-Placeholder}.Debug|x86.ActiveCfg = Debug|Win32 \n\t\t{ProjectGuid-Placeholder}.Debug|x86.Build.0 = Debug|Win32 \n\t\t{ProjectGuid-Placeholder}.Release|x64.ActiveCfg = Release|x64 \n\t\t{ProjectGuid-Placeholder}.Release|x64.Build.0 = Release|x64 \n\t\t{ProjectGuid-Placeholder}.Release|x86.ActiveCfg = Release|Win32 \n\t\t{ProjectGuid-Placeholder}.Release|x86.Build.0 = Release|Win32"
sln_projects = []
sln_sections = []

for d in os.listdir(work_folder):
    dir_path = os.path.join(work_folder, d)
    if os.path.isdir(dir_path) and '.vs' not in d:
        guid = str(uuid.uuid4()).upper()
        project_name = os.path.basename(dir_path)
        out_vcxproj_path = dir_path + os.sep + project_name + '.vcxproj'
        if os.path.exists(out_vcxproj_path):
            os.remove(out_vcxproj_path)
        dir_content = os.listdir(dir_path)
        c_file = dir_content[0]
        with open(vcxproj_temp_file, 'r') as file:
            temp_vcxproj = file.read()
            with open(out_vcxproj_path, 'w') as file2:
                out_vcxproj = ''
                out_vcxproj = temp_vcxproj.replace('FileName-Placeholder', c_file)
                out_vcxproj = out_vcxproj.replace('ProjectGuid-Placeholder', guid)
                out_vcxproj = out_vcxproj.replace('RootNamespace-Placeholder', project_name)
                file2.write(out_vcxproj)

        sln_project = temp_sln_project.replace('ProjectGuid-Placeholder', guid)
        sln_project = sln_project.replace('RootNamespace-Placeholder', project_name)
        sln_project = sln_project.replace('RootFolder-Placeholder', project_name)
        sln_project = sln_project.replace('RootFile-Placeholder', project_name)
        sln_projects.append(sln_project)
        sln_section = temp_sln_section.replace('ProjectGuid-Placeholder', guid)
        sln_sections.append(sln_section)

out_sln_path = work_folder + os.sep + 'ManyBugs.sln'
sln_projects_string = ''
sln_sections_string = ''
for sp in sln_projects:
    sln_projects_string += sp
for ss in sln_sections:
    sln_sections_string += ss
if os.path.exists(out_sln_path):
    os.remove(out_sln_path)
with open(sln_temp_file, 'r') as file3:
    temp_sln = file3.read()
    out_sln = temp_sln.replace('SlnProjects_Placeholder', sln_projects_string)
    out_sln = out_sln.replace('SlnSections_Placeholder', sln_sections_string)
    with open(out_sln_path, 'w') as file4:
        file4.write(out_sln)
