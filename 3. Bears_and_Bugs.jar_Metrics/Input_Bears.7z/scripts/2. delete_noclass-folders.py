import os
import shutil

# Specify path to folder with Bears_patches_files
work_folder = os.path.join('..', 'Bears_134')


for root, dirs,files in os.walk(work_folder):
    for d in dirs:
        if 'Fixed' not in d and 'Repaired' not in d and 'Buggy' not in d and 'ClassPath' not in d:
            has_class = False
            for root2, dirs2,files2 in os.walk(os.path.join(root, d)):
                for f in files2:
                    if '.class' in f:
                        has_class = True
                        break
            if not has_class:
                print(os.path.join(root, d))
                shutil.rmtree(os.path.join(root, d))
