import os

# Specify folder which contains compiled java files separated in packages
work_folder = os.path.join('..', 'Bears_Result_42_Packages')


with open('Bears_JArchitect_DirList.txt', 'w') as file:
    for d in os.listdir(work_folder):
        file.write('<Name>'+'...'+d+'</Name>\n')
        print('<Name>'+'...'+d+'</Name>')
