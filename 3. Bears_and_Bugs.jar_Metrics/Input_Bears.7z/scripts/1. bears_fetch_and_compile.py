import os
import shutil
import re
import subprocess
import requests

# REQUIREMENT: git clone https://github.com/bears-bugs/bears-benchmark.git
# NOTE: It is recommended to copy provided 'checkout_bug.py' script to
#   original '.../bears-benchmark/scripts' local git folder and commit changes
#   to prevent bugs during execution of this script (ex. stuck on non-master branch)
# If 'bears-benchmark' git folder stuck on non-master branch you can use following:
# 'git checkout -- .; git clean -f; git checkout master;'

# Specify full path to Bears_patch_files folder
bears_patches_path = os.path.join(os.getcwd(), '..','Bears_134')
# Specify full path to local_Bears_git folder
local_bears_folder = '/home/uros/Documents/GitHub/bears-benchmark'
# Specify location to bug_id_and_branch.json in local Bears git folder 
bears_json = os.path.join(local_bears_folder, 'scripts', 'data', 'bug_id_and_branch.json')

# Because of speeding up execution this script doesn't delete 'checkout-out bugs' in original 'bears-benchmark' folder,
# to force clean startup uncomment following code 
# shutil.rmtree('/home/uros/Documents/GitHub/bears-benchmark/bugs')
# os.mkdir('/home/uros/Documents/GitHub/bears-benchmark/bugs')


total_num = 0
compiled_num = 0
uncompiled_num = 0
no_bugid_num = 0
no_src_patch_file_num = 0
no_patched_repair_num = 0
no_org_file_in_workspace_num = 0
no_mvn_install = 0

i = 0

for root, dirs, files in os.walk(bears_patches_path):
    for patch_file in files:
        patch_file_path = os.path.join(root, patch_file)
            
        if '-Bears-' in patch_file_path and '.patch' in patch_file:
            print()
            print("====================================================================")
            print()
            
            total_num = total_num + 1
            i = i + 1
            print("CURRENT INDEX: "+str(total_num)+" "+patch_file)
            print("CURRENT DIR: "+root)
            
            # Get 'bears_bug_branch' from 'file_path'
            bears_bug_branch = ""
            search_result = re.search(r"Bears-(.*?)_", patch_file_path)
            if search_result:
                bears_bug_branch = search_result.group(1)

          
            # Get 'bears_bug_id' from '../scripts/data/bug_id_and_branch.json' based on 'bears_bug_branch'
            bears_bug_id = ""
            with open(bears_json, 'r') as bears_json_file:
                bears_json_content = bears_json_file.read()
                search_result = re.search(r"{.*\"bugId\": \"(.*?)\", .*?\"bugBranch\": \""+bears_bug_branch+r".*?}", bears_json_content, re.DOTALL)
                if search_result:
                    bears_bug_id = search_result.group(1)
                    print("BEARS_BUG_ID: "+bears_bug_id)
                else:
                    uncompiled_num = uncompiled_num + 1
                    no_bugid_num = no_bugid_num + 1
                    print("CANNOT FIND BEARS_BUG_ID")
                    shutil.rmtree(root)
                    continue

            # Running 'bears-benchmark/script/checkout_bug.py' with 'bears_bug_id' to obtain 'buggy-project'
            # NOTE: Don't forget to copy 'checkout_bug.py' to 'bears-benchmark/scripts' folder and commit changes
            workspace_path = os.path.join(local_bears_folder, 'bugs')
            checkout_project = os.path.join(workspace_path, bears_bug_id)
            if not os.path.exists(workspace_path):
                os.mkdir(workspace_path)
            if not os.path.exists(os.path.join(workspace_path,bears_bug_id)):
                command = ['python', os.path.join(local_bears_folder, 'scripts/checkout_bug.py'), '--bugId', bears_bug_id, '--workspace', workspace_path]
                try:
                    p1 = subprocess.run(command, capture_output=False, text=False)
                except subprocess.TimeoutExpired:
                    p1.terminate()

            # Get original 'java_file_location' and 'java_file_name' from 'patch_file'
            with open(patch_file_path, 'r', encoding='latin-1') as tool_patch_file:
                # Get 'org_java_file_path' and 'org_java_file_name' from 'tool_patch_file'(current file)
                org_java_file_path = ""
                org_java_file_name = ""
                tool_patch_content = tool_patch_file.read()
                if 'Arja' in root or 'Nopol' in root or 'RSRepair' in root or ('jKali' not in root and 'Kali' in root) or ('jGenProg' not in root and 'GenProg' in root):
                    search_result = re.search(r"---.*(src.*.java)", tool_patch_content)
                    if search_result:
                        for g in search_result.groups():
                            org_java_file_path = g
                            org_java_file_name = org_java_file_path.split(os.sep)[-1]
                            print("ORG_FILE_PATH: "+org_java_file_path)
                            print("ORG_FILE_NAME: "+org_java_file_name)
                    else:
                        uncompiled_num = uncompiled_num + 1
                        no_src_patch_file_num = no_src_patch_file_num + 1
                        print("IMPROPER SRC IN PATCH_FILE")
                        shutil.rmtree(root)
                        continue
                # In case of jMutRepair, Cardumen, jKali, jGenProg try to find 'src_path' in 'checkout_project'
                else:
                    first_line = tool_patch_content.split('\n', 1)[0].lstrip('--- ')
                    org_java_file_name = first_line.split(os.sep)[-1]
                    print(first_line.rstrip(org_java_file_name).rstrip(os.sep))
                    found_src_path = False
                    for root2, dirs2, files2 in os.walk(checkout_project):
                        for d in dirs2:
                            if first_line.rstrip(org_java_file_name).rstrip(os.sep) in os.path.join(root2, d):
                                found_src_path = True
                                org_java_file_path = os.path.join(root2, d, org_java_file_name)
                                print("ORG_FILE_PATH_ALT: "+org_java_file_path)
                                print("ORG_FILE_NAME_ALT: "+org_java_file_name)
                    if not found_src_path:
                        uncompiled_num = uncompiled_num + 1
                        no_src_patch_file_num = no_src_patch_file_num + 1
                        print("BUG IS NOT IN SRC PROVIDED BY PATCH_FILE")
                        shutil.rmtree(root)
                        continue

            # Get 'buggy-git-link' and 'manual-git-link' from 'buggy-project/bears.json'
            buggy_git_link = ""
            manual_git_link = ""
            project_bears_json_path = os.path.join(workspace_path,bears_bug_id, 'bears.json')
            with open(project_bears_json_path, 'r') as project_bears_json_file:
                bears_json_content = project_bears_json_file.read()
                search_result = re.search(r"\"commits\": {.*?\"fixerBuild\": {.*?\"url\": \"(.*?)\", .*?\"sha\"", bears_json_content, re.DOTALL)
                if search_result:
                    manual_git_link = search_result.group(1)
                search_result = re.search(r"\"commits\": {.*?\"buggyBuild\": {.*?\"url\": \"(.*?)\", .*?\"sha\"", bears_json_content, re.DOTALL)
                if search_result:
                    buggy_git_link = search_result.group(1)
            print("FIXED_GIT_LINK: "+manual_git_link)
            print("BUGGY_GIT_LINK: "+buggy_git_link)

            # Get 'buggy_version_java_file' from 'buggy_git_commit_url' and put in 'current folder/Buggy'
            buggy_raw_file_url = buggy_git_link.replace("commit","raw")+"/"+org_java_file_path
            new_buggy_file_path = os.path.join(root,"Buggy",org_java_file_name)
            if not os.path.exists(os.path.dirname(new_buggy_file_path)):
                print("BUGGY_RAW_LINK: "+buggy_raw_file_url)
                response = requests.get(buggy_raw_file_url)
                if response.status_code == 200:
                    # shutil.rmtree(os.path.dirname(new_buggy_file_path))
                    os.mkdir(os.path.dirname(new_buggy_file_path))
                    with open(new_buggy_file_path, 'w') as buggy_file:
                        buggy_file.write(response.text)
                    # When 'raw_file' is downloaded it can consist CRLF ending from DOS environment
                    command = 'dos2unix '+new_buggy_file_path+'; dos2unix'+patch_file_path
                    try:
                        p2 = subprocess.run(command, shell=True, capture_output=False, text=False)
                    except subprocess.TimeoutExpired:
                        p2.terminate()
                if os.path.exists(new_buggy_file_path):
                    print("BUGGY_RAW_FILE CREATED")
                else:
                    uncompiled_num = uncompiled_num + 1
                    print("NOT CREATED BUGGY_VERSION_FILE")
                    shutil.rmtree(root)
                    continue
            else:
                print('BUGGY_RAW_FILE STILL EXISTS: '+new_buggy_file_path)

            # Get 'manual_version_java_file' from 'manual_git_commit_url' and put in 'current folder/Manual'
            manual_raw_file_url = manual_git_link.replace("commit","raw")+"/"+org_java_file_path
            new_manual_file_path = os.path.join(root,"Manual",org_java_file_name)
            if not os.path.exists(os.path.dirname(new_manual_file_path)):
                print("FIXED_RAW_LINK: "+manual_raw_file_url)
                response = requests.get(manual_raw_file_url)
                if response.status_code == 200:
                    # shutil.rmtree(os.path.dirname(new_manual_file_path))
                    # On Linux, when 'raw_file' is downloades it can consist CRLF ending from DOS environment
                    if os.name == 'posix':
                        command = 'dos2unix '+new_manual_file_path
                        try:
                            p3 = subprocess.run(command, shell=True, capture_output=False, text=False)
                        except subprocess.TimeoutExpired:
                            p3.terminate()
                    os.mkdir(os.path.dirname(new_manual_file_path))
                    with open(new_manual_file_path, 'w') as manual_file:
                        manual_file.write(response.text)
                if os.path.exists(new_manual_file_path):
                    print("FIXED_RAW_FILE CREATED")
                else:
                    uncompiled_num = uncompiled_num + 1
                    print("NOT CREATED FIXED_VERSION_FILE")
                    shutil.rmtree(root)
                    continue
            else:
                print('FIXED_RAW_FILE STILL EXISTS: '+new_manual_file_path)


            # Apply 'patch' on 'buggy_version_java_file' to obtain 'auto_version_java_file'
            new_auto_file_path = os.path.join(root,"Auto",org_java_file_name)
            if not os.path.exists(os.path.dirname(new_auto_file_path)):
                os.mkdir(os.path.dirname(new_auto_file_path))
            command = ['patch', new_buggy_file_path, '-i', patch_file_path, '-o', new_auto_file_path]
            print(command)
            try:
                p4 = subprocess.run(command, capture_output=False, text=False)
            except subprocess.TimeoutExpired:
                p4.terminate()
            reapired_folder_content = str(os.listdir(os.path.dirname(new_auto_file_path)))
            if '.rej' in reapired_folder_content or org_java_file_name not in reapired_folder_content:
                uncompiled_num = uncompiled_num + 1
                no_patched_repair_num = no_patched_repair_num + 1
                print("NOT SUCCESSFULLY PATCHED REPAIRED_VERSION_FILE ")
                # It doesn't remove 'root' folder but only 'auto' folder,
                # maybe patch process have some easy to fix error
                shutil.rmtree(os.path.dirname(new_auto_file_path))
                if len(os.listdir(os.path.dirname(new_auto_file_path))) == 0:
                    shutil.rmtree(root)
                continue
            else:
                print('REPAIRED_VERSION_FILE SUCCESSFULY CREATED')

            # Running 'bears-benchmark/script/compile_bug.py' on 'workspace_path/bears_bug_id' and
            # copy 'new_version_java_file' to obtain 'new_version_class_files' and 
            # copy them to 'new_version_java_file_folder'
            if os.path.exists(os.path.join(workspace_path,bears_bug_id,org_java_file_path)):
                target_dir = os.path.join(checkout_project, 'target')
                
                # Get desired path target classes from one of any possible src/main/java path combination
                tmp_org_class_file_dir = ""
                if os.path.join('src', 'main', 'java') in org_java_file_path:
                    tmp_org_class_file_dir = org_java_file_path.replace(os.path.join('src', 'main', 'java'), os.path.join('target', 'classes'))
                elif os.path.join('src', 'java') in org_java_file_path:
                    tmp_org_class_file_dir = org_java_file_path.replace(os.path.join('src', 'java'), os.path.join('target', 'classes'))
                elif os.path.join('src', 'main') in org_java_file_path:
                    tmp_org_class_file_dir = org_java_file_path.replace(os.path.join('src', 'main'), os.path.join('target', 'classes'))
                else:
                    tmp_org_class_file_dir = org_java_file_path.replace("src", os.path.join('target', 'classes'))
                org_class_file_dir = os.path.join(checkout_project,os.path.dirname(tmp_org_class_file_dir))      

                new_version_file_paths = [new_buggy_file_path, new_manual_file_path, new_auto_file_path]
                for version_file_path in new_version_file_paths:
                    # Delete existing 'checkout_project/target' folder
                    if os.path.exists(target_dir):
                        shutil.rmtree(target_dir)
                    if not os.path.exists(version_file_path.replace('.java','.class')):
                        # Copy goten 'version_java_files' to 'workspace_checkout_project'
                        shutil.copy(version_file_path, os.path.join(checkout_project, org_java_file_path))
                        print()
                        print("FROM: "+version_file_path)
                        print("JAVA_PATH: "+os.path.join(checkout_project, org_java_file_path))
                        print("CLASS_DIR: "+org_class_file_dir)
                        print("TO: "+os.path.dirname(version_file_path))
                        command = ['python', os.path.join(local_bears_folder, 'scripts', 'compile_bug.py'), '--bugId', bears_bug_id, '--workspace', workspace_path]
                        try:
                            p5 = subprocess.run(command, capture_output=False, text=False)
                        except subprocess.TimeoutExpired:
                            p5.terminate()
                        if os.path.exists(org_class_file_dir):
                            for f in os.listdir(org_class_file_dir):
                                if org_java_file_name.replace('.java','') in f:
                                    print("COPIED CLASS_FILE: "+f)
                                    print("FROM: "+os.path.join(checkout_project,org_class_file_dir,f))
                                    print("TO: "+os.path.dirname(version_file_path))
                                    # Copy certain compiled 'workspace_checkout_project_class_files' to 'version_java_file_dir'
                                    shutil.copy(os.path.join(checkout_project,org_class_file_dir,f), os.path.dirname(version_file_path))
                            if version_file_path == new_auto_file_path:
                                compiled_num = compiled_num + 1
                        else:
                            if version_file_path == new_auto_file_path:
                                uncompiled_num = uncompiled_num + 1
                            no_mvn_install = no_mvn_install + 1
                            print("NOT MVN INSTALL CHECKOUTED PROJECT: "+version_file_path)
                            shutil.rmtree(root)
                            break
                    else:
                        if version_file_path == new_auto_file_path:
                            compiled_num = compiled_num + 1
                        print("STILL EXISTS: "+version_file_path.replace('.java','.class'))
            else:
                uncompiled_num = uncompiled_num + 1
                no_org_file_in_workspace_num = no_org_file_in_workspace_num + 1
                print("NOT CONTAINS ORG_FILE_PATH: "+os.path.join(workspace_path,bears_bug_id))
                shutil.rmtree(root)

# Remove 'checkout bugs' after execution
shutil.rmtree(os.path.join(local_bears_folder, 'bugs'))

# Print some execution info
print("\n\n\n")
print(f"TOTAL_NUM: {total_num}")
print(f"COMPILED_NUM: {compiled_num}")
print(f"UNCOMPILED_NUM: {uncompiled_num}")
print(f"NO_BUGID_NUM: {no_bugid_num}")
print(f"NO_SRC_IN_PATCH_NUM: {no_src_patch_file_num}")
print(f"NO_PATCHE_REPAIR_NUM: {no_patched_repair_num}")
print(f"NO_ORG_FILE_IN_WORKSPACE_NUM: {no_org_file_in_workspace_num}")
print(f"NO_MVN_INSTALL: {no_mvn_install}")
