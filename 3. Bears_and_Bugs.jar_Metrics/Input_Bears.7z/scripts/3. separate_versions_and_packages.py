import os
import shutil

# Specify path to folder which contains Bears_compiled_files
work_folder = ('..', 'Bears_134')

# Specify output folder to write package hierarchy
output_folder = os.path.join('..', 'Bears_Result_42_Packages')
if not os.path.exists(output_folder):
    os.mkdir(output_folder)


def get_line_from_file(file_path, word):
    with open(file_path, 'r') as fp:
        # read all lines in a list
        lines = fp.readlines()
        for line in lines:
            # check if string present on a current line
            if line.startswith(word):
                return line.split(' ')[1].replace(';','')

# Iterate over all files in the directory
for project_dir in os.listdir(work_folder):
    for root, dirs, files in os.walk(os.path.join(work_folder, project_dir)):
        for file in files:
            file_path = os.path.join(work_folder, project_dir, root, file)
            if ".java" in file_path and not "src" in file_path and ('Manual' in root or 'Auto' in root or 'Buggy' in root):
                file_name = file.replace('.java','')
                package_name = get_line_from_file(file_path, 'package').strip()
                print()
                src_folder = os.path.join(output_folder, root.split(os.sep)[-2]+"_"+root.split(os.sep)[-1], 'src', package_name.replace('.',os.sep))
                bin_folder = os.path.join(output_folder, root.split(os.sep)[-2]+"_"+root.split(os.sep)[-1], 'bin', package_name.replace('.',os.sep))
                print(src_folder)
                print(bin_folder)
                print(os.path.basename(root)+" -> "+package_name+": "+file)
                if not os.path.exists(src_folder):
                    os.umask(0)
                    os.makedirs(src_folder, mode=0o777)
                if not os.path.exists(bin_folder):
                    os.umask(0)
                    os.makedirs(bin_folder, mode=0o777)
                for root2, dirs2, files2 in os.walk(root):
                    for file2 in files2:
                        file_path2 = os.path.join(root2, file2)
                        if file_name in file2 and '.java' in file2:
                            dest_name = os.path.join(src_folder, file2)
                            if not os.path.exists(dest_name):
                                shutil.copy(file_path2, dest_name)
                        if file_name in file2 and '.class' in file2:
                            dest_name = os.path.join(bin_folder, file2)
                            if not os.path.exists(dest_name):
                                shutil.copy(file_path2, dest_name)

